/**
 * @license Highcharts JS v7.2.1 (2019-10-31)
 * @module highcharts/modules/treemap
 * @requires highcharts
 *
 * (c) 2014-2019 Highsoft AS
 * Authors: Jon Arild Nygard / Oystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/treemap.src.js';
