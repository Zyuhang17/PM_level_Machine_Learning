<?Php
$host_name = "mydb.itap.purdue.edu"; // Host name
$database = "g1109698"; // Database name
$username = "g1109698";          // Database user id 
$password = "SEVERELY26";          // Database password

//error_reporting(0);// With this no error reporting will be there
//Connect to the database and execute queries

$connection = mysqli_connect($host_name, $username, $password, $database);

if (!$connection) {
    echo "Error: Unable to connect to MySQL.<br>";
    echo "<br>Debugging errno: " . mysqli_connect_errno();
    echo "<br>Debugging error: " . mysqli_connect_error();
    exit;
}
?>