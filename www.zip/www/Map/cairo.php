<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	<title>Sensor Placement in Cairo</title>
	<!-- Style of the Google Maps map -->
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
		width: 75%;
        height: 100%;
        margin: 0;
        padding: 0;
      }
	  div.hist_data {
		position: absolute;
		right: 100px;
		top: 0px;
		z-index: -1;
	  }
	  .button {
  background-color: orange;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  position: absolute;
  right: 50px;
  top: 25px;
}
    </style>
  </head>
  
<html>
<body>
  <div id="map"></div>
<script>
// variable represents if the sensor is fixed or mobile
var customLabel = {
        Fixed: {
          label: 'F'
        },
        Mobile: {
          label: 'M'
        }
      };
// Initializing the map centering at given latitude and longitude
function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(30.0444, 31.2357),
          zoom: 12
        });
	
	//Creating an Info Window for each marker 
      var infoWindow = new google.maps.InfoWindow;

//All the variables are created with information coming from our database. One marker per sensor is placed on the map. 
downloadUrl('https://web.ics.purdue.edu/~g1109698/Map/cairoXML.xml', function(data) {
  var xml = data.responseXML;
  var markers = xml.documentElement.getElementsByTagName('Locations');
  Array.prototype.forEach.call(markers, function(markerElem) {
    var ID = markerElem.getAttribute('L_ID'); //sensor ID
    
    var point = new google.maps.LatLng(
        parseFloat(markerElem.getAttribute('Latitude')), //Latitude of each sensor location
        parseFloat(markerElem.getAttribute('Longitude'))); //Longitude of each sensor location
	
	
	var content = '<div id="content">'+
      '<div id="siteNotice">'+
      '</div>'+
      '<h3>Sensor ID: ' + ID + '<br>' +
      '</div>';
	
	
	// Position each marker at latitude and longitude taken from database
    var icon = customLabel[ID] || {};
    var marker = new google.maps.Marker({
      map: map,
      position: point,
      label: icon.label
    });
	
	// If user clicks on a marker, the Info Window will appear. 
	marker.addListener('click', function() {
    infoWindow.setContent(content);
    infoWindow.open(map, marker);
  });
  });
  });
}

 function downloadUrl(url,callback) {
 var request = window.ActiveXObject ?
     new ActiveXObject('Microsoft.XMLHTTP') :
     new XMLHttpRequest;

 request.onreadystatechange = function() {
   if (request.readyState == 4) {
     request.onreadystatechange = doNothing;
     callback(request, request.status);
   }
 };
 request.open('GET', url, true);
        request.send(null);
      }
	  function doNothing() {}
</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCV6sHPkJ3n9RMvsY5FeYXECFQPpjQmUoA&callback=initMap">
    </script>

<div class="hist_data">
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">

      // Load the Visualization API and the corechart package.
      google.charts.load('current', {packages: ['corechart']});
      google.charts.setOnLoadCallback(drawChart);
	  
      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
		var parameters = document.getElementById('parameter').value;
			data.addColumn('string', 'Month');
			data.addColumn('number', 'Parameter Value');
			for(i = 0; i < my_2d.length; i++)
			data.addRow([my_2d[i][0], parseInt(my_2d[i][1])]);
			var options = {
			title: 'Chosen Parameter versus Time',
			curveType: 'function',
			width: 500,
			height: 300,
			legend: { position: 'bottom' }
			};

			var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
			chart.draw(data, options);
	  }
</script>
<!-- Different inputs the user can add to see real time data and historical data -->
<a href="home.html" class="button">Back to Home Page</a>
<img src='images/qualtic_logo.png' style='position:absolute; top:0; right:300px;' width='150px' height='80px'/>
</br></br></br></br>
<h1>Analytics Dashboard</h1>
<h4>Fill in the following fields </h4>
<form name="user" action="cairo.php" method="post">
  Sensor ID: <input type="number" name="ID" min="1" max="20" required>
  Date: <input id="datefield" type="date" name="date" min='2017-01-01' max='2020-12-25' required><br>
  Time (only input round hours): <input type="time" name="user_time" required><br>
  Parameter: <br><input type="radio" name="parameter" value="Temperature" id="parameter" required> Temperature (°C)<br>
			 <input type="radio" name="parameter" value="Humidity" id="parameter" required> Humidity (%)<br>
			 <input type="radio" name="parameter" value="Pressure" id="parameter" required> Pressure (Pa)<br>
			 <input type="radio" name="parameter" value="AQI" id="parameter" required> AQI <br><br>
			 <input type="submit" name="submitbtn">	<br><br>
</form>
<?php
if (!empty($_POST['submitbtn']))
{
    require "config.php";// Database connection

$input1 = $_POST["ID"]; //Sensor ID
$input2 = $_POST["date"]; //Date
$input3 = $_POST["parameter"]; //Parameter chosen (Temperature, Humidity, Pressure, AQI)
$input4 = $_POST["user_time"]; //Time
if($stmt = $connection->query("SELECT Time, $input3 FROM Readings WHERE Date = '$input2' AND S_ID = '$input1' AND Name='Cairo'")){

$php_data_array = Array(); // create PHP array
  
while ($row = $stmt->fetch_row()) {
   
   $php_data_array[] = $row; // Adding to array
   }

}else{
echo $connection->error;
}
//print_r( $php_data_array);
// You can display the json_encode output here. 

// Transfor PHP array to JavaScript two dimensional array 
echo "<script>
        var my_2d = ".json_encode($php_data_array)."
</script>";

$result = mysqli_query($connection,"SELECT Pressure, Temperature, Humidity, AQI, AQI_Rating FROM Readings WHERE Date = '$input2' AND S_ID = '$input1' AND Name='Cairo' AND Time = '$input4'");
echo "<br>";
// Prints all the data depending on the user's inputs from the database in real time.
while($row = mysqli_fetch_array($result))
{
// Prints a face depending on the air quality rating. 
if ($row['AQI_Rating'] == "Good") {
echo "<img src='images/Good.png' width='75' height='75'/>";
}
else if ($row['AQI_Rating'] == "Moderate") {
echo "<img src='images/Moderate.png' width='75' height='75'/>";
}
else if ($row['AQI_Rating'] == "Unhealthy for sensitive groups") {
echo "<img src='images/Sensitive.png' width='75' height='75'/>";
}
else if ($row['AQI_Rating'] == "Unhealthy") {
echo "<img src='images/Unhealthy.png' width='75' height='75'/>";
}
else if ($row['AQI_Rating'] == "Very Unhealthy") {
echo "<img src='images/Very_Unhealthy.png' width='75' height='75'/>";
}
else if ($row['AQI_Rating'] == "Hazardous") {
echo "<img src='images/Hazardous.png' width='75' height='75'/>";
}
else {
	echo "The air Quality Rating is Unknown.";
}
echo "<br>";
echo "<br>";
echo "At this Time and Location:";
echo "<br>";
echo "<br>";
echo "<strong>AQI (Air Quality Index) is: </strong>" . $row['AQI'];
echo "<br>";
echo "<strong>Air Quality Rating: </strong>" . $row['AQI_Rating'];
echo "<br>";
echo "<strong>Pressure is: </strong>" . $row['Pressure'] . " Pa";
echo "<br>";
echo "<strong>Temperature is: </strong>" . $row['Temperature'] . " °C";
echo "<br>";
echo "<strong>Humidity is: </strong>" . $row['Humidity'] ." %";
echo "<br>";
}

//Prints the inputs chosen by the user
echo "<br>";
echo "<br>";

$out1 = "Chosen Sensor ID: " . $input1 ;
echo $out1;
echo "<br>";

$out2 = "Date: " . $input2 ;
echo $out2;
echo "<br>";

$out3 = "Chosen Parameter: " . $input3 ;
echo $out3;
echo "<br>";

$out4 = "Chosen Time: " . $input4 ;
echo $out4;
echo "<br>";

mysqli_close($con);
}
?>
<div id="curve_chart"></div>
<br><br>



<a href="http://www.sparetheair.com/aqi.cfm" style='position:absolute; bottom:10; right:40;'><img src='images/PM2017.png' style='position:absolute; bottom:10; right:10;' width='400px' height='325px'></img>  Image Source </a>

</div>
</body>
</html>